## Version 0.0.5
- Added TV Lights option, whether or not the TV should cast light or not.

## Version 0.0.4
- Fixed previous version not working.

## Version 0.0.3

- Add ability to change media folder to something else.

## Version 0.0.2

- Add Readme

## Version 0.0.1

Initial Release
